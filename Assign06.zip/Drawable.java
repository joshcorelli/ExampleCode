package edu.corellj.Assign06;

import edu.corellj.Assign05.CharImage;

public interface Drawable {
    public abstract void draw(CharImage map);
}
